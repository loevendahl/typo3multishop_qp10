<?php
$GLOBALS['TYPO3_CONF_VARS']['SC_OPTIONS']['ext/multishop/pi1/classes/class.mslib_payment.php']['mslib_payment'][]='EXT:multishop_quickpay10/class.multishop_quickpay10.php:&tx_multishop_quickpay10->mslib_payment';
?>